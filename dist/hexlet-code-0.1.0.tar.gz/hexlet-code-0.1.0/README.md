### Hexlet tests and linter status:
[![Actions Status](https://github.com/miaalvess/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/miaalvess/python-project-lvl1/actions)

<a href="https://codeclimate.com/github/miaalvess/python-project-lvl1/test_coverage"><img src="https://api.codeclimate.com/v1/badges/2bd402e2c6779ce5292a/test_coverage" /></a>
