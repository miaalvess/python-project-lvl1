### Hexlet tests and linter status:
[![Actions Status](https://github.com/miaalvess/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/miaalvess/python-project-lvl1/actions)