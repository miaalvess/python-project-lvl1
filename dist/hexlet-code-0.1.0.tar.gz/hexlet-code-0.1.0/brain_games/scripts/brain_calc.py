from brain_games.games.calc import calc_game
from brain_games.games.logic import logic


def main():
    logic(calc_game())

if __name__ == '__main__':
    main()
