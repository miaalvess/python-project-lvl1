from brain_games.games.even import parity_check

def main():
    parity_check()

if __name__ == '__main__':
    main()


