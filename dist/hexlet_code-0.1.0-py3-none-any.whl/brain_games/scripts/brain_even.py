from brain_games.games import even
from brain_games.logic import logic


def main():
    logic(even)

if __name__ == '__main__':
    main()


